import Table from "../../Components/Table";

const Historial = () => {
    return (
        <div>
            <Table />
        </div>
    );
}

export default Historial;
