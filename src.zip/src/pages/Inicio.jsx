import React from 'react';

const Inicio = () => {
  return (
    <main className="flex-1 p-8 ">
      <h1 className="text-3xl font-bold mb-4">Contenido de la Página de Inicio</h1>
      <p>¡Bienvenido a la aplicación!</p>
    </main>
  );
};

export default Inicio;