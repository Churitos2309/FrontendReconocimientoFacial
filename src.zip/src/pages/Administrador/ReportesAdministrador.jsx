import Table from "../../Components/Table";

const ReportesAdministrador = () => {
    return (
        <div>
            <Table />
        </div>
    );
}

export default ReportesAdministrador;
