import Table from "../../Components/Table";

const ReportesInstructor = () => {
    return (
        <div>
            <Table />
        </div>
    );
}

export default ReportesInstructor;
