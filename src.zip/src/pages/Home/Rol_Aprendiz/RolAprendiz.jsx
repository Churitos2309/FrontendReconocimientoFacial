import React from 'react';

const RolAprendiz = () => {
    return (
        <div>
            <h1>fff</h1>
        </div>
    );
}

export default RolAprendiz;
