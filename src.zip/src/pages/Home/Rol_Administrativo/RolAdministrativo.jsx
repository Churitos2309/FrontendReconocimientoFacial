import React from 'react';

const RolAdministrativo = () => {
    return (
        <div>
            <h1>
                hhh
            </h1>
        </div>
    );
}

export default RolAdministrativo;
