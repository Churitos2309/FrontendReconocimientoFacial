import React from 'react';

const RolInstructor = () => {
    return (
        <div>
            <h1>hhh</h1>
        </div>
    );
}

export default RolInstructor;
